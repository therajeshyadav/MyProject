const express=require("express");
const router=express.Router();





const listingController=require("../controllers/listings.js");

router
.route("/")
.get(listingController.index)
.post(listingController.createListing);

  
router.get("/new",listingController.renderNewForm);
router
.route("/:id") 
.get(listingController.showListing)
.put(listingController.updateListing) 
.delete(listingController.destroyListing);

router.get("/:id/edit",listingController.renderEditForm);

module.exports=router;